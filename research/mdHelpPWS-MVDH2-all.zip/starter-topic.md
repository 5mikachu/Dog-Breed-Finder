# 0. Introduction

## 0.1 Preface

Choosing what dish to pick from a restaurant menu can be a daunting task. Especially for someone like me - a dyslexic person - deciphering an often way to densely packed menu can be an overwhelming experience. But even for people without dyslexia, navigating a menu can be confusing. All to often, digital menus are simply PDFs of the physical one, offering little improvement in accessibility. Moreover, identifying dishes suitable for those with dietary restrictions - being from allergies ore simply a diet - can be a frustrating ordeal. Small, easily overlooked pictographs often provide the only indication of allergens, leaving diners to play a frustrating and dangerous game of "spot the hidden danger."

This also applies to choosing what breed of dog to adopt. As information about dietary and physical needs are often hard to find and often obscure the actual data behind pay-walls or walls of text. This makes it hard for people to make an informed decision about what breed of dog to adopt. 

## 0.2 Problem

The problem is that the information about the dietary and physical needs of dogs is often hard to find and often obscure the actual data behind pay-walls or walls of text. This makes it hard for people to make an informed decision about what breed of dog to adopt.

## 0.3 Research questions

This research aims to explore how data visualization can be used to assist individuals in the process of selecting a suitable dog breed.

### 0.3.1 Main research question

> How can data visualization be used to assist people with choosing a dog breed that fits their needs and situation.

### 0.3.2 Secondary research questions

1. How can data visualization be employed
2. What are the most common setbacks of data visualization?
3. What is open source?
4. How does the open source spirit relate to the spirit of this PWS?
5. What is used to store large amounts of data digitally?
6. What is Python?
7. Can python be used in conjunction to HTML?

These questions will be answered throughout the research and have been subdivided into four main topics;

| # | Title              | Questions |
|---|--------------------|-----------|
| 1 | Data Visualization | 1 and 2   |
| 2 | Open Source        | 3 and 4   |
| 3 | JSON               | 5         |
| 4 | Python             | 6 and 7   |

In these, more questions will come up and even more answers will be given. The list of questions given is not an exhaustive list of all the questions, but merely the questions that were used as a jumping of point for the topics.
