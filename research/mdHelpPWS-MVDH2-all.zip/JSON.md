# 3. JSON

## 3.1 What is JSON

> JSON is the lingua franca of the web  
> — Arun Gupta, *Java EE 7 Essentials*

JSON is an abbreviation for JavaScript Object Notation (W3Schools.com, n.d.) and is used to store large amounts of data. Although the name mentions JavaScript, it is not only usable with JavaScript; on the contrary, JSON can be used in most — if not all — of the most widely used programming languages.

JSON uses two "structures": a collection of name/value pairs and an ordered list of values (JSON, n.d.). In JSON, these can take multiple forms:

#### Forms of JSON Components

| Type   | Information                                           | Starts With | Ends With |
|--------|-------------------------------------------------------|-------------|-----------|
| object | Names / Values                                        | `{`         | `}`       |
| array  | Values                                                | `[`         | `]`       |
| value  | String / Number / Boolean[^1] / NULL / object / array | n/a         | n/a       |
| string | Unicode characters                                    | `"`         | `"`       |
| number | Numbers                                               | n/a         | n/a       |

## 3.2 Why Use JSON

As mentioned before, JSON can be interfaced with from nearly all widespread programming languages (JOSN.org, n.d.).

JSON's format is lightweight and easy to read for both humans and machines. Its structure is composed of name/value pairs, which makes it highly flexible for encoding complex data structures, such as arrays and objects. JSON’s simplicity allows developers to quickly interpret and manipulate data, particularly in web development where the interchange of data between servers and clients is common.

One of the key features of JSON is that it uses *text* format, which makes it compatible with almost any data interchange application. Whether you're working with Python, Java, or JavaScript, JSON's simplicity reduces the need for complex mechanisms for data handling, speeding up development time.

## 3.3 JSON and HTML

JSON and HTML[^2] work really well together in web development (JSON.org, n.d.). While HTML is used for structuring the content of web pages, JSON is responsible for the exchange of data. In a web application, the front-end (HTML) often requires fresh data from the back-end (server), and JSON can be used for communication between the two.

An example of their interaction can be seen in AJAX[^3] requests, in which JSON is often the preferred data format due to its lightweight nature. When an AJAX request is made, JSON serves as the way to save the data, allowing the server to send this data back to the front-end without a page refresh.


## 3.4 JSON vs XML

Before JSON became the standard for data interchange on the web, XML (eXtensible Markup Language) was more widely used. While XML is more suited for representing and storing complex data structures, it is also more verbose and thus less lightweight. JSON, on the other hand, is more compact and more human-readable. Making it a preferred choice for most modern applications.

### 3.4.1 Main Differences Between JSON and XML

- **JSON** is more lightweight, using fewer characters to represent data.
- **XML** requires opening and closing tags, while JSON uses braces `{}` and brackets `[]` for structure.
- Parsing JSON is generally faster than XML parsing in most programming environments.
- JSON supports a smaller set of data types compared to XML but is easier to manipulate.

In essence, JSON's simplicity makes it ideal for applications that need to quickly exchange data with minimal overhead.

[^1]: Boolean: A value, either True or False.
[^2]: HTML: HyperText Markup Language, the standard markup language for creating web pages.  
[^3]: AJAX: Asynchronous JavaScript and XML.
