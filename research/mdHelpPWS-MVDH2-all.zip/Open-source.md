# 2. Open Source

## 2.1 What is Open Source

> "Open source software is software with source code that anyone can inspect, modify, and enhance."  
> — opensource.com

The source[^1] of an open-source product is — as the name implies — open and can be viewed and modified by anyone without prior approval. However, this does not necessarily mean the product has to be free. Open source projects can monetize their product by charging for extended services or for compiling the program[^2] (opensourcecom, n.d.).

Open source is built upon three main pillars:

1. **Transparency**: Sharing information, not just the source, helps others build *upon* the work instead of duplicating efforts.
2. **Collaboration**: Working together increases efficiency and expands the scale of solvable problems.
3. **Community**: Communities guide decision-making, making the product more inclusive.

An example of an open-source-monetized project is [Aseprite](https://aseprite.org/). Aseprite’s source code is available [here](https://github.com/aseprite/aseprite) (capello, n.d.), and anyone can modify it. However, users must either pay for the compiled version or spend time compiling it themselves.

### 2.1.1 Open Source in Switzerland

Switzerland now requires all government software to be open source. (Nichols Vaughan, 2024) In Switserlands case this means a certain persentage of the software being develeped is needs be be under an open source lisence and needs be be pulicaly available.

This code is available on GitHub under one big government collection. 

## 2.2 What Is Not Open Source

If something is not open source, only a select group of people can see and modify the source. For example, programs like Microsoft Word or Adobe Photoshop are closed source. Their source code is not accessible for inspection, modification, or feature additions by the public. Only the company or specific developers have control over such programs.

Closed-source software is often used to protect intellectual property or maintain strict control over software use.

## 2.3 Open Source Licenses

Even though open source means anyone can view or modify the software, there are still rules about its use. These rules are defined by licenses[^3]. Open source licenses allow creators to specify what others can or cannot do with their intellectual property.

Some licenses are permissive, allowing almost unrestricted use, while others require shared improvements or prohibit commercial use.

### 2.3.1 Popular Open-Source Licenses

- **MIT License**: Allows nearly unrestricted use, provided original creators are credited.
- **GNU General Public License (GPL)**: Ensures modifications remain open source and are shared with the community.
- **Apache License**: Permits free use, modification, and distribution with added protections for the original authors.

## 2.4 Open Source: Why (Not)

There are many reasons to use or avoid open-source software. Let’s explore a few:

### 2.4.1 Why Use Open Source?

- **Cost**: Open source software is often free, saving money for individuals and businesses.
- **Transparency**: Open code ensures no hidden agendas or security risks.
- **Community Support**: Active communities improve the software and offer help.

### 2.4.2 Why Not Use Open Source?

- **Monetization**: Profiting from open-source software can be challenging.
- **Time and Effort**: It may require more effort, such as compiling software or dealing with limited documentation.
- **Secrets**: Some businesses prefer closed-source solutions to protect their innovations.

## 2.5 Open Source and My PWS

In my PWS, I aim to use as many open-source products as possible, aligning with the principles of transparency, community, and collaboration. For example:

- Instead of Microsoft Word, I’ll use *LibreOffice Writer*.
- Instead of Google Chrome, I’ll use *Firefox*.

While avoiding closed-source products entirely may not always be possible, I will strive to minimize their use by finding open-source alternatives.  
For this, I’ll frequently consult resources like [opensourcealternative.to](https://www.opensourcealternative.to/), which lists open-source counterparts for popular closed-source programs.

## 2.6 Examples of Open Source Alternatives

| Closed-Source Program | Open-Source Alternative                                    |
|-----------------------|------------------------------------------------------------|
| Microsoft Word        | [LibreOffice Writer](https://www.libreoffice.org/)         |
| Microsoft Windows     | [Fedora Linux](https://getfedora.org/)                     |
| Microsoft VSCode      | [JetBrains PyCharm CE](https://www.jetbrains.com/pycharm/) |

Using open-source alternatives saves money, promotes transparency, and contributes to the community by improving the software for everyone.

[^1]: Source: All components of a product, including images, code, and videos.  
[^2]: Compiling: The process of translating source code into machine code that a computer can execute.  
[^3]: License: A legal document specifying how intellectual property can be used and shared.
