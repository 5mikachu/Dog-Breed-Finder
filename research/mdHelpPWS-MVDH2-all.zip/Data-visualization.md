# 1. Data Visualization

## 1.1 Current situation

> "Remember when we thought stupidity was caused by a lack of proper data...?"  
> — Unknown

In this age of data, understanding and effectively communicating data is becoming more and more important. Sadly, data is easy to manipulate and the actual data is often hard to understand due to its static nature.

Data is either presented as pages of text filled with raw numbers or as oversimplified visuals that can underestimate the audience's ability to interpret the information (Palmer, 2023). This leads to a gap in reader comprehension — between those who can manipulate data on their own and those who are only presented with processed data.

### 1.1.1 Restaurant Menus

An example we all know is restaurant menus. It is often hard to know what contains what and if certain items could interfere with any dietary needs. For people with dyslexia, this is even more challenging, as the ingredients are typically listed in smaller fonts, and menu design often prioritizes style over function. And although many restaurants are moving their menus to a digital medium, they often just scan the menu, failing to take advantage of the interactivity offered by the digital platform.

## 1.2 Interaction

If restaurants instead made their menus interactive, such as with toggles for allergies, it would mean less work and a more satisfactory experience for the user.

## 1.3 Data Visualizations in the Digital Age

In the current digital era, data visualizations are integral to decision-making processes. From businesses to governments, graphical representations of data help quickly identify trends, correlations, and outliers that would otherwise be hidden in numbers. However, while technology offers numerous tools for generating charts and graphs, the design of these visuals remains paramount.

### 1.3.1 Importance of Visual Design

Data visualization is not just about showing data; it’s about communication (The Problem With Your Data Visualization (Devetry, n.d.). The visual presentation must ensure clarity, accuracy, and efficiency. Poorly designed visuals can lead to misinterpretation, confusion, or even mistrust in the data presented. An essential element of effective data visualization is choosing the right type of graph or chart for the data.

#### Forms of Graphs and Charts

| Type of Data                      | Suitable Chart Type |
|-----------------------------------|---------------------|
| Time series data[^1]              | Line chart[^2]      |
| Comparison of categories          | Bar chart[^3]       |
| Proportions                       | Pie chart[^4]       |
| Correlation between variables[^5] | Scatter plot[^6]    |

Data visualizations, when done correctly, make complex data more digestible for a wider audience, helping decision-makers grasp insights quickly.

### 1.3.2 Accessibility in Data Visualizations

Much like text-based information, visual data can pose challenges for people with disabilities. For example, individuals with color blindness may struggle to differentiate between colors in a chart, while those with dyslexia may find the accompanying labels difficult to read. Ensuring that data visualizations are accessible is essential in today’s design practices.

Here are some best practices for accessible data visualizations (Palmer, 2023):

- Use high-contrast colors[^7] and avoid relying on color alone to convey meaning.
- Include alternative text[^8] for graphs and charts, describing the key trends or findings.
- Provide clear labels and annotations that are easy to read and comprehend.
- Ensure that interactive elements, like hover-over details or clickable points, are intuitive for all users.

By considering these factors, data visualizations can become more inclusive, catering to a broader audience, including those with disabilities.

## 1.4 Tools for Creating Data Visualizations

Various tools are available that help create powerful, dynamic, and interactive data visualizations. Some of these tools are user-friendly for beginners, while others offer more advanced customization options.

#### Popular Tools for Data Visualization

| Tool               | Description                                                                        |
|--------------------|------------------------------------------------------------------------------------|
| Tableau            | A powerful tool for creating interactive and shareable dashboards[^9].             |
| Power BI           | Microsoft’s tool for building interactive reports with data from multiple sources. |
| Google Data Studio | A free tool that allows users to transform data into informative dashboards.       |
| D3.js              | A JavaScript library[^10] for creating custom data visualizations in web browsers. |

Each tool has its strengths, from drag-and-drop simplicity to deep customization through coding. The right tool depends on the user's needs, technical ability, and the complexity of the data involved.

### 1.4.1 The Future of Data Visualization

With the growing influence of artificial intelligence (AI) and machine learning (ML), data visualization is evolving beyond static graphs. Predictive analytics and automated insights can now be integrated into visualizations, allowing users not only to view past data but also to anticipate future trends.

In the future, we can expect more interactive and immersive experiences, where users can manipulate data in real time[^11], explore different scenarios, and receive instant feedback. The combination of AI-driven insights and intuitive interfaces will make data visualization an even more essential tool in decision-making processes.

[^1]: Time series data: Data points indexed in time order, often used to track changes over time.  
[^2]: Line chart: A type of graph that displays information as a series of data points connected by straight lines.  
[^3]: Bar chart: A chart that presents categorical data with rectangular bars representing the values.  
[^4]: Pie chart: A circular chart divided into sectors to illustrate numerical proportions.  
[^5]: Correlation: A statistical measure that describes the extent to which two variables change together.  
[^6]: Scatter plot: A graph with points plotted to show a relationship between two variables.
[^7]: High-contrast colors: Colors that have a large difference in brightness or hue, making them easy to distinguish.  
[^8]: Alternative text: Descriptive text that can be read by screen readers to provide information for visually impaired users.
[^9]: Dashboard: A graphical interface that displays key information in a summarized format.  
[^10]: JavaScript library: Pre-written JavaScript code that allows for easier development of certain functionalities.
[^11]: Real time: The immediate processing of data as it comes in, without delay.

