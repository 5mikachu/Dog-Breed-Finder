# Sources

## APA

Capello, D. (n.d.). Aseprite. Animated Sprite Editor & Pixel Art Tool. https://www.aseprite.org/  
Fedora Linux. (n.d.). The Fedora Project. https://fedoraproject.org/  
Home | LibreOffice - Free and private office suite - Based on OpenOffice - Compatible with Microsoft. (n.d.). https://www.libreoffice.org/  
JSON. (n.d.). https://www.json.org/json-en.html  
Open source - JetBrains. (n.d.). JetBrains. https://www.jetbrains.com/opensource/  
Open source alternatives to proprietary software. (n.d.). https://www.opensourcealternative.to/  
Opensource.com. (n.d.). What is open source? https://opensource.com/resources/what-open-source  
Palmer, M. (2023, June 26). Data Visualization Is Broken—Here’s How To Fix It. Forbes. Retrieved December 30, 2024, from https://www.forbes.com/councils/forbestechcouncil/2023/06/26/data-visualization-is-broken-heres-how-to-fix-it/  
The problem with your data visualization (And how to fix it) | Devetry. (n.d.). https://devetry.com/blog/the-problem-with-your-data-visualization-and-how-to-fix-it/  
Vaughan-Nichols, S. (2024, July 29). Switzerland federal government requires releasing its software as open source. ZDNET. https://www.zdnet.com/article/switzerland-now-requires-all-government-software-to-be-open-source/  
W3Schools.com. (n.d.-a). https://www.w3schools.com/whatis/whatis_json.asp  
W3Schools.com. (n.d.-b). https://www.w3schools.com/python/  
W3Schools.com. (n.d.-c). https://www.w3schools.com/js/js_api_intro.asp  
W3Schools.com. (n.d.-d). https://www.w3schools.com/js/js_ajax_intro.asp  
Welcome to Python.org. (2024, December 19). Python.org. https://www.python.org/  

## LaTeX

``` latex
@misc{unknown-author-no-dateA,
	title = {{W3Schools.com}},
	url = {https://www.w3schools.com/whatis/whatis_json.asp},
}
@misc{unknown-author-no-dateB,
	title = {{JSON}},
	url = {https://www.json.org/json-en.html},
}
@misc{capello-no-date,
	author = {Capello, David},
	title = {{Aseprite}},
	url = {https://www.aseprite.org/},
}
@misc{unknown-author-no-dateC,
	title = {{Home | LibreOffice - Free and private office suite - Based on OpenOffice - Compatible with Microsoft}},
	url = {https://www.libreoffice.org/},
}
@misc{unknown-author-no-dateD,
	title = {{Fedora Linux}},
	url = {https://fedoraproject.org/},
}
@misc{unknown-author-no-dateE,
	title = {{Open source - JetBrains}},
	url = {https://www.jetbrains.com/opensource/},
}
@misc{unknown-author-no-dateF,
	title = {{Open source alternatives to proprietary software}},
	url = {https://www.opensourcealternative.to/},
}
@article{vaughan-nichols-2024,
	author = {Vaughan-Nichols, Steven},
	month = {7},
	title = {{Switzerland federal government requires releasing its software as open source}},
	year = {2024},
	url = {https://www.zdnet.com/article/switzerland-now-requires-all-government-software-to-be-open-source/},
}
@misc{unknown-author-no-dateG,
	title = {{W3Schools.com}},
	url = {https://www.w3schools.com/python/},
}
@misc{unknown-author-no-dateH,
	title = {{W3Schools.com}},
	url = {https://www.w3schools.com/js/js_api_intro.asp},
}
@misc{unknown-author-no-dateI,
	title = {{W3Schools.com}},
	url = {https://www.w3schools.com/js/js_ajax_intro.asp},
}
@misc{opensourcecom-no-date,
	author = {Opensource.com},
	title = {{What is open source?}},
	url = {https://opensource.com/resources/what-open-source},
}
@misc{unknown-author-no-dateJ,
	title = {{The problem with your data visualization (And how to fix it) | Devetry}},
	url = {https://devetry.com/blog/the-problem-with-your-data-visualization-and-how-to-fix-it/},
}
@misc{palmer-2023,
	author = {Palmer, Mike},
	month = {6},
	title = {{Data Visualization Is Broken—Here’s How To Fix It}},
	year = {2023},
	url = {https://www.forbes.com/councils/forbestechcouncil/2023/06/26/data-visualization-is-broken-heres-how-to-fix-it/},
}
@misc{unknown-author-2024,
	month = {12},
	title = {{Welcome to Python.org}},
	year = {2024},
	url = {https://www.python.org/},
}
```
